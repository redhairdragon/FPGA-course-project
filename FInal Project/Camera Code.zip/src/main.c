
#include <stdio.h>
#include <xio.h>
#include <math.h>
#include <string.h>
#include "xparameters.h"
#include "cam_ctrl_header.h"
#include "vmodcam_header.h"


#define blDvmaCR		0x00000000 // Control Reg Offset
#define blDvmaFWR		0x00000004 // Frame Width Reg Offset
#define blDvmaFHR		0x00000008 // Frame Height Reg Offset
#define blDvmaFBAR	0x0000000c // Frame Base Addr Reg Offset
#define blDvmaFLSR	0x00000010 // Frame Line Stride Reg Offeset
#define blDvmaHSR		0x00000014 // H Sync Reg Offset
#define blDvmaHBPR	0x00000018 // H Back Porch Reg Offset
#define blDvmaHFPR	0x0000001c // H Front Porch Reg Offset
#define blDvmaHTR		0x00000020 // H Total Reg Offset
#define blDvmaVSR		0x00000024 // V Sync Reg Offset
#define blDvmaVBPR	0x00000028 // V Back Porch Reg Offset
#define blDvmaVFPR	0x0000002c // V Front Porch Reg Offset
#define blDvmaVTR		0x00000030 // V Total Reg Offset

#define GRID_WIDTH 4


//void drawRec(int x1,y1,x2,y2);
inline int red(u16 x);
inline int blue(u16 x);
inline int green(u16 x);
inline int redish(int r,int g,int b,u16 x);
inline int blueish(int r,int g,int b,u16 x);
inline int greenish(int r,int g,int b,int x);
inline int whiteish(int r,int g,int b);
inline int blackish(int r,int g,int b,u16 x);

int main() {
	u32 lDvmaBaseAddress = XPAR_DVMA_0_BASEADDR;
	int posX, posY;
	for(posX = 0; posX<2560; posX++)
		for(posY = 0; posY<720; posY++)
			XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+posX), (posX/40)<<4);

	XIo_Out32(lDvmaBaseAddress + blDvmaHSR, 40); // hsync
	XIo_Out32(lDvmaBaseAddress + blDvmaHBPR, 260); // hbpr
	XIo_Out32(lDvmaBaseAddress + blDvmaHFPR, 1540); // hfpr
	XIo_Out32(lDvmaBaseAddress + blDvmaHTR, 1650); // htr
	XIo_Out32(lDvmaBaseAddress + blDvmaVSR, 5); // vsync
	XIo_Out32(lDvmaBaseAddress + blDvmaVBPR, 25); // vbpr
	XIo_Out32(lDvmaBaseAddress + blDvmaVFPR, 745); // vfpr
	XIo_Out32(lDvmaBaseAddress + blDvmaVTR, 750); // vtr

	XIo_Out32(lDvmaBaseAddress + blDvmaFWR, 0x00000500); // frame width
	XIo_Out32(lDvmaBaseAddress + blDvmaFHR, 0x000002D0); // frame height
	XIo_Out32(lDvmaBaseAddress + blDvmaFBAR, XPAR_DDR2_SDRAM_MPMC_BASEADDR); // frame base addr
	XIo_Out32(lDvmaBaseAddress + blDvmaFLSR, 0x00000A00); // frame line stride
	XIo_Out32(lDvmaBaseAddress + blDvmaCR, 0x00000003); // dvma enable, dfl enable


//	CamIicCfg(XPAR_CAM_IIC_1_BASEADDR, CAM_CFG_640x480P);
//	CamCtrlInit(XPAR_CAM_CTRL_1_BASEADDR, CAM_CFG_640x480P, 0);


	for(posX = 0; posX<2560; posX++)
		for(posY = 0; posY<720; posY++)
			XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+posX), 0x0000);

	int r_grid[GRID_WIDTH][GRID_WIDTH];
	int g_grid[GRID_WIDTH][GRID_WIDTH];
	int b_grid[GRID_WIDTH][GRID_WIDTH];
	int bk_grid[GRID_WIDTH][GRID_WIDTH];
	int wt_grid[GRID_WIDTH][GRID_WIDTH];
	int c_grid[GRID_WIDTH][GRID_WIDTH];
	int blank[GRID_WIDTH][GRID_WIDTH];
	int x,y;
	u16 color;
	int r,g,b;

	int i,j;

	while(1){
		xil_printf("Processing\r\n");
		char buff[256];
		sprintf(buff, "%d\r\n", XIo_In16(XPAR_DDR2_SDRAM_MPMC_BASEADDR));
		xil_printf("%s\r\n",buff);

		memset(r_grid,0,sizeof r_grid);
		memset(b_grid,0,sizeof r_grid);
		memset(g_grid,0,sizeof r_grid);
		memset(bk_grid,0,sizeof r_grid);
		memset(wt_grid,0,sizeof r_grid);
		memset(blank,0,sizeof r_grid);
		memset(c_grid,0,sizeof r_grid);


		int r_max=0,r_x=0,r_y=0;
		int g_max=0,g_x=0,g_y=0;
		int b_max=0,b_x=0,b_y=0;
		for(posX = 0; posX<640; posX++){
			for(posY = 0; posY<480; posY++){
				color=XIo_In16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+posX));
				x=posX/(640/GRID_WIDTH);
				y=posY/(480/GRID_WIDTH);
				r=red(color);
				g=green(color);
				b=blue(color);
				if(redish(r,g,b,color)){
					r_grid[x][y]+=1;
				}
				else if(blueish(r,g,b,color)){
					b_grid[x][y]+=1;
				}
				else if(greenish(r,g,b,color)){
					g_grid[x][y]+=1;
				}
				else if(blackish(r,g,b,color)){
					bk_grid[x][y]+=1;
				}
				else if(whiteish(r,g,b)){
					wt_grid[x][y]+=1;
				}

				else{
					blank[x][y]+=1;
				}

			}
		}

		for (i=0;i<GRID_WIDTH;i++){
			for(j=0;j<GRID_WIDTH;j++){
				if(r_grid[i][j]>r_max){
					r_max=r_grid[i][j];
					r_x=i;r_y=j;
				}
				if(g_grid[i][j]>g_max){
					g_max=g_grid[i][j];
					g_x=i;g_y=j;
				}
				if(b_grid[i][j]>b_max){
					b_max=b_grid[i][j];
					b_x=i;b_y=j;
				}
			}
		}

		c_grid[r_x][r_y]=1;
		c_grid[g_x][g_y]=2;
		c_grid[b_x][b_y]=3;
		xil_printf("Max R x: %d, y: %d\r\n",r_x,r_y);
		xil_printf("Max G x: %d, y: %d\r\n",g_x,g_y);
		xil_printf("Max B x: %d, y: %d\r\n",b_x,b_y);
		for (i=0;i<GRID_WIDTH;i++){
			for(j=0;j<GRID_WIDTH;j++){
				if(c_grid[i][j]==0){
					if(bk_grid[i][j]>r_grid[i][j]&&bk_grid[i][j]>g_grid[i][j]&&bk_grid[i][j]>b_grid[i][j]&&bk_grid[i][j]>wt_grid[i][j]&&bk_grid[i][j]>=blank[i][j])
						c_grid[i][j]=4;//bk
					else if(wt_grid[i][j]>r_grid[i][j]&&wt_grid[i][j]>g_grid[i][j]&&wt_grid[i][j]>b_grid[i][j]&&wt_grid[i][j]>bk_grid[i][j]&&wt_grid[i][j]>blank[i][j])
						c_grid[i][j]=5;//wt
					else
						c_grid[i][j]=6;
				}
			}
		}
		for(posX = 0; posX<640; posX++){
			for(posY = 0; posY<480; posY++){
				x=posX/(640/GRID_WIDTH);
				y=posY/(480/GRID_WIDTH);
				if(c_grid[x][y]==1)
					XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+(posX+640)),0b111100000000);
				else if(c_grid[x][y]==2)
					XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+(posX+640)),0b000011110000);
				else if(c_grid[x][y]==3)
					XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+(posX+640)),0b000000001111);
				else if(c_grid[x][y]==4)
					XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+(posX+640)),0b000000000000);
				else if(c_grid[x][y]==5)
					XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+(posX+640)),0b111111111111);
				else
					XIo_Out16(XPAR_DDR2_SDRAM_MPMC_BASEADDR + 2*(posY*2560+(posX+640)),0b111111110000);
			}
		}
	}
}
inline int red(u16 x){
	return ((0xF<<8)&x)>>8;
}
inline int blue(u16 x){
	return (0xF)&x;
}
inline int green(u16 x){
	return ((0xF<<4)&x)>>4;
}

inline int redish(int r,int g,int b,u16 x){
//	if(r>(b+g))
	if(((r>(b+1)&&r>(g+1))))
		return 1;
	else
		return 0;

}

inline int blueish(int r,int g,int b,u16 x){
//	if(b>=0b100&&g<0b11&&r<0b11)
	if(x<15)
		return 0;
	if(x<300&&((b>(r+1)&&b>(g+1))))
		return 1;
	else
		return 0;

}

inline int greenish(int r,int g,int b,int x){
	if(g>(b+1)&&g>(r+1)&&x>400&&x<700)
		return 1;
	else
		return 0;

}
//void drawRec
inline int whiteish(int r,int g,int b){
	if((g>=0b111)&&(b>=0b111)&&(r>=0b111))
		return 1;
	else
		return 0;
}

inline int blackish(int r,int g,int b,u16 x){
	if (x<20)
		return 1;
	if((g<=0b11)&&(b<0b11)&&(r<0b11))
		return 1;
	return 0;
}
