#include <stdio.h>
#include <stdlib.h>
#include <xparameters.h>
#include <xgpio.h>
#include <xuartns550_l.h>
#include <xio.h>
#include <xenv_standalone.h>
#include <xil_printf.h>
#include <xstatus.h>
#include <xuartlite_l.h>
#include <time.h>
#include <xil_io.h>
#include "ai.h"
#include "platform.h"

#define clockwiseAngleModifier 3
#define counterClockwiseAngleModifier 3

void print(char *str);
typedef enum {RIGHT = 1, LEFT = 3, UP = 2, DOWN = 4} FACING;

// Global Variables
FACING currentFacing = RIGHT;
struct Coordinate goal;
struct Coordinate robot;
struct Coordinate box;

void goForward(int unit) {
	return;
}
void wait2sec() {
	int i, j;
	for (j=0;j<2;j++)
	for (i=0;i<25000000;i++)
	asm("nop");
}



void rotateTo(FACING facing) {
	if (facing == currentFacing) {
		return;
	}
	else if (facing > currentFacing) {
		int rotateDegree = 90 * (facing - currentFacing);	// calculate the degree to rotate
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x98);	// put the robot into script mode
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x0D);	// script length is 13 = 0x0D
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);	// put it in drive mode

		if (rotateDegree == 90) {

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x64);	// velocity: 100mm/s
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);	// turn in place counterclockwise0

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x5A - counterClockwiseAngleModifier);
			currentFacing = facing;
		}
		else if (rotateDegree == 180) {


			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x64);	// velocity: 100mm/s
					XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);	// turn in place counterclockwise0

					XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xB4 - counterClockwiseAngleModifier);
			currentFacing = facing;
		}
		else {


			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x64);	// velocity: 100mm/s
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF);	// turn in place clockwise

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);

			/*XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x0E - counterClockwiseAngleModifier);
			currentFacing = facing;*/
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xA6 + clockwiseAngleModifier);
			currentFacing = facing;
		}


		// the next 3 lines stop the robot
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);	// put it in drive mode
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);	// no velocity
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x99);	// Play script



	}
	else {	// facing < currentFacing
		int rotateDegree = 90 * (facing - currentFacing);	// calculate the degree to rotate
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x98);	// put the robot into script mode
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x0D);	// script length is 13 = 0x0D
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);	// put it in drive mode

		if (rotateDegree == -90) {

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x64);	// velocity: 100mm/s
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF);	// turn in place clockwise

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);


			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xA6 + clockwiseAngleModifier);
			currentFacing = facing;
		}
		else if (rotateDegree == -180) {


			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x64);	// velocity: 100mm/s
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF);	// turn in place clockwise

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);


			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0xFF);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x4C + clockwiseAngleModifier);
			currentFacing = facing;
		}
		else {
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x64);	// velocity: 100mm/s
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);	// turn in place counterclockwise0

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);

			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
			XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x5A - counterClockwiseAngleModifier);
			currentFacing = facing;
		}


		// the next 3 lines stop the robot
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);	// put it in drive mode
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);	// no velocity
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00); XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
		XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x99);	// Play script
	}
	wait2sec();
	return;
}


void moveForward40cm() {
//	This drives 40cm and stop
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x98);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x0D);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x2C);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x80);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9C);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x90);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x99);	// Play script
	wait2sec();
	return;

}
void driveInASquare() {
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x98);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x11);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x2C);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x80);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9C);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x90);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x89);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x2C);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x01);

	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x9D);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x00);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x5A);
	XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x99);
	wait2sec();
	return;
}
void moveLeft() {
	rotateTo(LEFT);
	moveForward40cm();
}
void moveRight() {
	rotateTo(RIGHT);
	moveForward40cm();
}
void moveUp() {
	rotateTo(UP);
	moveForward40cm();
}
void moveDown() {
	rotateTo(DOWN);
	moveForward40cm();
}



void actFromAI(char* steps) {
	int index = 0;
	for (index; steps[index] != 0; index = index + 1) {
		if (steps[index] == 'u')	// up
			moveUp();
		else if (steps[index] == 'd') // down
			moveDown();
		else if (steps[index] == 'l')	// left
			moveLeft();
		else	// right
			moveRight();
	}
}











int main()
{
init_platform();


//xil_printf(act);

XUartNs550_SetBaud(XPAR_RS232_UART_0_BASEADDR, XPAR_XUARTNS550_CLOCK_HZ, 57600);
XUartNs550_SetLineControlReg(XPAR_RS232_UART_0_BASEADDR, XUN_LCR_8_DATA_BITS);
// Initialize
XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x80);
XUartNs550_SendByte(XPAR_RS232_UART_0_BASEADDR,0x84);
wait2sec();
//rotateTo(DOWN);
char *map1[] = {"0040",
                "1100",
                "3120",
                "0000"};
char* act = actions(map1);

actFromAI(act);

return 0;
}


