/*
 * Copyright (c) 2009-2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include <stdlib.h>
#include "platform.h"
#include "xparameters.h"
#include "xgpio.h"
#include "stdio.h"
#include "xstatus.h"
#include "xbasic_types.h"

XGpio GpioOutput; /* The driver instance for GPIO Device configured as O/P */
XGpio GpioInput;  /* The driver instance for GPIO Device configured as I/P */

void print(char *str);

int main()
{

    init_platform();
    print("---Entering main---\n\r");
    int a=0,b=0;
    a=getInt();
    b=getInt();
    printf("%d\r\n",a*b);
    int prod=a*b;
    if((prod)-100>0){
    	print("turn on led\r\n");
    	turnOnLED();
    }


   print("---Exiting main---\n\r");
    return 0;
}

int turnOnLED(){
	int Status = XGpio_Initialize(&GpioOutput, XPAR_LEDS_8BIT_DEVICE_ID);
	if (Status != XST_SUCCESS)  {
	  return XST_FAILURE;
	}
	XGpio_SetDataDirection(&GpioOutput, 1, 0x0);
	Xuint32 mydata =3;
	XGpio_DiscreteWrite(&GpioOutput, 1, mydata);
	return 0;
}

int getInt(){
	char* buffer=malloc(200);
	memset(buffer,0,200);
	int index=0;
	while(1){
		int temp=getchar();
		if(temp==13)
			break;
		if(temp!=0){
			buffer[index]=temp;
			printf("%c",buffer[index]);
			index++;
		}
	}
	buffer[index+1]='\0';
	int result=atoi(buffer);
	free(buffer);
	printf("\r\n");
	return result;
}
