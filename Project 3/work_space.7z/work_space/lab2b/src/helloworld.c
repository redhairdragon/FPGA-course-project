/*
 * Copyright (c) 2009-2012 Xilinx, Inc.  All rights reserved.
 *
 * Xilinx, Inc.
 * XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS" AS A
 * COURTESY TO YOU.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION AS
 * ONE POSSIBLE   IMPLEMENTATION OF THIS FEATURE, APPLICATION OR
 * STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS IMPLEMENTATION
 * IS FREE FROM ANY CLAIMS OF INFRINGEMENT, AND YOU ARE RESPONSIBLE
 * FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE FOR YOUR IMPLEMENTATION.
 * XILINX EXPRESSLY DISCLAIMS ANY WARRANTY WHATSOEVER WITH RESPECT TO
 * THE ADEQUACY OF THE IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO
 * ANY WARRANTIES OR REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE
 * FROM CLAIMS OF INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY
 * AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xparameters.h"
#include "xgpio.h"
#include "stdio.h"
#include "xstatus.h"
#include "xbasic_types.h"
#include <stdlib.h>
XGpio GpioOutput; /* The driver instance for GPIO Device configured as O/P */
XGpio GpioInput;  /* The driver instance for GPIO Device configured as I/P */

void print(char *str);
char mapKey(int value);
int getInt();
int main()
{
    init_platform();
    print("start\r\n");
	int Status = XGpio_Initialize(&GpioOutput, XPAR_KEYPAD_DEVICE_ID);
	if (Status != XST_SUCCESS)  {
	  return XST_FAILURE;
	}
	Status = XGpio_Initialize(&GpioInput, XPAR_KEYPAD_DEVICE_ID);
	if (Status != XST_SUCCESS)  {
	  return XST_FAILURE;
	}
	int p2=getInt();
	int p1 =0;
	int count=0;

	while(1){
		count++;
		if(count%4==0){
			XGpio_SetDataDirection(&GpioOutput, 1, 14<<4);
			XGpio_DiscreteWrite(&GpioOutput,1,14<<4);
			XGpio_SetDataDirection(&GpioInput, 1, 0xF);
			p1=XGpio_DiscreteRead(&GpioInput,1);
		}
		if(count%4==1){
			XGpio_SetDataDirection(&GpioOutput, 1, 13<<4);
			XGpio_DiscreteWrite(&GpioOutput,1,13<<4);
			XGpio_SetDataDirection(&GpioInput, 1, 0xF);
			p1=XGpio_DiscreteRead(&GpioInput,1);
		}

		if(count%4==2){
			XGpio_SetDataDirection(&GpioOutput, 1, 11<<4);
			XGpio_DiscreteWrite(&GpioOutput,1,11<<4);
			XGpio_SetDataDirection(&GpioInput, 1, 0xF);
			p1=XGpio_DiscreteRead(&GpioInput,1);
		}

		if(count%4==3){
			XGpio_SetDataDirection(&GpioOutput, 1, 7<<4);
			XGpio_DiscreteWrite(&GpioOutput,1,7<<4);
			XGpio_SetDataDirection(&GpioInput, 1, 0xF);
			p1=XGpio_DiscreteRead(&GpioInput,1);
		}
		char temp=mapKey(p1);
		if (temp=='1'||temp=='2'||temp=='3'){
			char str[2];
			str[0]=temp;
			str[1]=0;
			p1=atoi(str);
			break;
		}
	}

	if (p1==p2){
		print("Same\r\n");
		return 0;
	}

	if(p1==1){
		print("FPGA: 1 (rock)\r\n");
		if(p2==2){print("COMP (paper) wins\r\n"); return 0;}
		print("COMP (scissors)\r\n");
		print("FPGA wins\r\n"); return 0;
	}
	if(p1==2){
		print("FPGA: 2 (paper)\r\n");
		if(p2==3){print("COMP (scissors) wins\r\n"); return 0;}
		print("COMP (rock)\r\n");
		print("FPGA wins\r\n"); return 0;
	}
	if(p1==3){
		print("FPGA: 3 (scissors)\r\n");
		if(p2==1){print("COMP (rock) wins\r\n"); return 0;}
		print("COMP (paper)\r\n");
		print("FPGA wins\r\n"); return 0;
	}
	print("End\r\n");

    return 0;
}

char mapKey(int value){
	switch (value){
		case 239:
			return '\0';
		case 238:
			return '1';
		case 237:
			return '4';
		case 235:
			return '7';
		case 231:
			return '0';
		case 223:
			return '\0';
		case 222:
			return '2';
		case 221:
			return '5';
		case 219:
			return '8';
		case 215:
			return '9';
		case 191:
			return '\0';
		case 190:
			return '3';
		case 189:
			return '6';
		case 187:
			return '9';
		case 183:
			return 'E';
		case 127:
			return '\0';
		case 126:
			return 'A';
		case 125:
			return 'B';
		case 123:
			return 'C';
		case 119:
			return 'D';
	}
	return 0;
}

int getInt(){
	char* buffer=malloc(200);
	memset(buffer,0,200);
	int index=0;
	while(1){
		int temp=getchar();
		if(temp==13)
			break;
		if(temp!=0){
			buffer[index]=temp;
			printf("%c",buffer[index]);
			index++;
		}
	}
	buffer[index+1]='\0';
	int result=atoi(buffer);
	free(buffer);
	printf("\r\n");
	return result;
}




